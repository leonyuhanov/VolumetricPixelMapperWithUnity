using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CollisionScript1 : MonoBehaviour
{
    public GameObject mainHook;
	
	Color cObj;
	
	// Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
	
	private void OnTriggerEnter(Collider other)
    {
		cObj = other.GetComponent<Renderer>().material.GetColor("_Color");
		cObj.a = 1;
		mainHook.GetComponent<Renderer>().material.SetColor("_Color", cObj);
	}	
	
	private void OnTriggerExit(Collider other)
    {
		cObj = 	mainHook.GetComponent<Renderer>().material.GetColor("_Color");
		cObj.a = 0;
		mainHook.GetComponent<Renderer>().material.SetColor("_Color", cObj);
	}
		 
}
