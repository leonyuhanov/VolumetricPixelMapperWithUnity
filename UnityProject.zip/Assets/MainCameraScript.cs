using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Threading;
using System.Text;
using System.Net;
using System.Net.Sockets;


public class MainCameraScript : MonoBehaviour
{
    public GameObject mainHook;
	public GameObject secondaryHook;
	Vector3 pointPos = new Vector3(0f, 30f, 0f), secPointPos = new Vector3(30f, 15f, 0f);
	GameObject aCube;
	
	//colour objects
    const byte maxValue = 250;
    static byte[] colourList = new byte[9 * 3] { maxValue, 0, 0, maxValue, maxValue, 0, 0, maxValue, 0, 0, maxValue, maxValue, 0, 0, maxValue, maxValue, 0, maxValue, maxValue, maxValue, maxValue, maxValue, 0, 0, 0, 0, 0 };
    colourObject cObject = new colourObject(maxValue, 9, colourList);
	Color cObj, animObjectColour;
	float[] currentColourF = new float[3];
	int cIndex=0;
	
	int frameRate = 30;
	int numOfRows = 32;
	const int numOfPixels = 384;
	int[] pixelsInRow = {14,10,14,10,14,10,14,10,14,10,14,10,14,10,14,10,14,10,14,10,14,10,14,10,14,10,14,10,14,10,14,10};
	Color[] LEDs = new Color[numOfPixels];
	float fadeValue = 0.2f;
	
	int rowCnt=0, cCnt=0, pxCount=0, dataCnt=0;
	GameObject objectPointer;
	
	//UDP RX Stuff
	const int dataPacketPort=1000;
	const int dataPacketSize = numOfPixels*3;
    UdpClient dataClient;
	IPEndPoint remoteIpEndPoint = new IPEndPoint(IPAddress.Parse("192.168.1.111"), dataPacketPort);
	byte[] pixelData = new byte[dataPacketSize];
	
	// Start is called before the first frame update
    void Start()
    {
        //Set up frame rate
		QualitySettings.vSyncCount = 0;
		Application.targetFrameRate = frameRate;
		
		//Set all to black & set up LED array
		cObj.r=0;
        cObj.g=0;
        cObj.b=0;
		pxCount=0;
		for(rowCnt=0; rowCnt<numOfRows; rowCnt++)
		{
			for(cCnt=0; cCnt<pixelsInRow[rowCnt]; cCnt++)
			{
				objectPointer = GameObject.Find("r"+rowCnt+"c"+cCnt);
				objectPointer.GetComponent<Renderer>().material.SetColor("_Color", cObj);
				LEDs[pxCount].r = cObj.r;
				LEDs[pxCount].g = cObj.g;
				LEDs[pxCount].b = cObj.b;
				pxCount++;
			}
		}
		
		//set up networking
		dataClient = new UdpClient(dataPacketPort);
		
    }

    // Update is called once per frame
    void Update()
    {
		//change colour
		currentColourF = cObject.getColour(cIndex % cObject._bandWidth, true);
		cIndex+=10;
		animObjectColour.r = currentColourF[0];
		animObjectColour.g = currentColourF[1];
		animObjectColour.b = currentColourF[2];
		animObjectColour.a = 67/256;
		mainHook.GetComponent<Renderer>().material.SetColor("_Color", animObjectColour);
		//dump into LED array
		populateLEDData();
		txData();
    }
	
	void populateLEDData()
	{
		pxCount=0;
		for(rowCnt=0; rowCnt<numOfRows; rowCnt++)
		{
			for(cCnt=0; cCnt<pixelsInRow[rowCnt]; cCnt++)
			{
				objectPointer = GameObject.Find("r"+rowCnt+"c"+cCnt);
				LEDs[pxCount] = objectPointer.GetComponent<Renderer>().material.GetColor("_Color");
				
				//do fade IF alpha is 0
				if(LEDs[pxCount].a==0)
				{
					if(LEDs[pxCount].r-fadeValue>=0){LEDs[pxCount].r-=fadeValue;}else{LEDs[pxCount].r=0;}
					if(LEDs[pxCount].g-fadeValue>=0){LEDs[pxCount].g-=fadeValue;}else{LEDs[pxCount].g=0;}
					if(LEDs[pxCount].b-fadeValue>=0){LEDs[pxCount].b-=fadeValue;}else{LEDs[pxCount].b=0;}
					objectPointer.GetComponent<Renderer>().material.SetColor("_Color", LEDs[pxCount]);
				}
				pxCount++;
			}
		}
		
		//hscan
		if(pointPos.y>0)
		{
			pointPos.y-=.5f;
			mainHook.transform.position = pointPos;
		}
		else
		{
			pointPos.y=30;
			mainHook.transform.position = pointPos;
		}
		//vscan
		if(secPointPos.x>-30)
		{
			secPointPos.x-=.5f;
			secondaryHook.transform.position = secPointPos;
		}
		else
		{
			secPointPos.x=30;
			secondaryHook.transform.position = secPointPos;
		}
		
		
	}
	
	void txData()
	{
		dataCnt=0;
		for(pxCount=0; pxCount<numOfPixels; pxCount++)
		{
			pixelData[dataCnt] = (byte)(LEDs[pxCount].r * 255f);
			pixelData[dataCnt+1] = (byte)(LEDs[pxCount].g * 255f);
			pixelData[dataCnt+2] = (byte)(LEDs[pxCount].b * 255f);
			dataCnt+=3;
		}
		dataClient.Send(pixelData, dataPacketSize, remoteIpEndPoint);
	}
	
}

public class colourObject
{
    byte[,] _primaryColours;
    byte[,] _colourTable = new byte[3, 3];
    int[,] _modifierTable = new int[2, 3];
    byte[] _tempColour = new byte[3];
    float[] _tempColourF = new float[3];
    byte _colourBlockCount;
    int _coloursPerBlock;
    public int _bandWidth;
    byte _cnt;
    int _primColIndex;
    float _mIndex;
    string bString;

    public colourObject()
    {

    }

    public colourObject(byte maxValue)
    {
        _colourBlockCount = 6;
        _primaryColours = new byte[_colourBlockCount, 3];
        _coloursPerBlock = maxValue;
        _bandWidth = _coloursPerBlock * _colourBlockCount;
        //Fill out default primary colours
        //[[255,0,0],[255,255,0],[0,255,0],[0,255,255],[0,0,255],[255,0,255]]
        _primaryColours[0, 0] = maxValue;
        _primaryColours[0, 1] = 0;
        _primaryColours[0, 2] = 0;

        _primaryColours[1, 0] = maxValue;
        _primaryColours[1, 1] = maxValue;
        _primaryColours[1, 2] = 0;

        _primaryColours[2, 0] = 0;
        _primaryColours[2, 1] = maxValue;
        _primaryColours[2, 2] = 0;

        _primaryColours[3, 0] = 0;
        _primaryColours[3, 1] = maxValue;
        _primaryColours[3, 2] = maxValue;

        _primaryColours[4, 0] = 0;
        _primaryColours[4, 1] = 0;
        _primaryColours[4, 2] = maxValue;

        _primaryColours[5, 0] = maxValue;
        _primaryColours[5, 1] = 0;
        _primaryColours[5, 2] = maxValue;
    }

    public colourObject(byte maxValue, byte colourBlockCount, byte[] rgbColourArray)
    {
        _colourBlockCount = colourBlockCount;
        _primaryColours = new byte[_colourBlockCount, 3];
        _coloursPerBlock = maxValue;
        _bandWidth = _coloursPerBlock * _colourBlockCount;
        for (_cnt = 0; _cnt < colourBlockCount; _cnt++)
        {
            _primaryColours[_cnt, 0] = rgbColourArray[_cnt * 3];
            _primaryColours[_cnt, 1] = rgbColourArray[(_cnt * 3) + 1];
            _primaryColours[_cnt, 2] = rgbColourArray[(_cnt * 3) + 2];
        }
    }

    public float[] getColour(int colourIndex, bool returnFloat)
    {
        _primColIndex = colourIndex / _coloursPerBlock;
        _colourTable[0, 0] = _primaryColours[_primColIndex, 0];
        _colourTable[0, 1] = _primaryColours[_primColIndex, 1];
        _colourTable[0, 2] = _primaryColours[_primColIndex, 2];

        _colourTable[1, 0] = _primaryColours[(_primColIndex + 1) % _colourBlockCount, 0];
        _colourTable[1, 1] = _primaryColours[(_primColIndex + 1) % _colourBlockCount, 1];
        _colourTable[1, 2] = _primaryColours[(_primColIndex + 1) % _colourBlockCount, 2];

        gradientGenerator(colourIndex % _coloursPerBlock, _coloursPerBlock);

        _tempColour[0] = _colourTable[2, 0];
        _tempColour[1] = _colourTable[2, 1];
        _tempColour[2] = _colourTable[2, 2];

        if (returnFloat == false)
        {
            _tempColourF[0] = (float)_tempColour[0];
            _tempColourF[1] = (float)_tempColour[1];
            _tempColourF[2] = (float)_tempColour[2];
            return _tempColourF;
        }
        else
        {
            _tempColourF[0] = (float)((float)_tempColour[0] / _coloursPerBlock);
            _tempColourF[1] = (float)((float)_tempColour[1] / _coloursPerBlock);
            _tempColourF[2] = (float)((float)_tempColour[2] / _coloursPerBlock);
            return _tempColourF;
        }
    }
    public void gradientGenerator(int colourIndex, int bandwidth)
    {
        for (_cnt = 0; _cnt < 3; _cnt++)
        {
            //fill modifier
            if (_colourTable[1, _cnt] > _colourTable[0, _cnt]) { _modifierTable[0, _cnt] = 1; }
            else if (_colourTable[1, _cnt] < _colourTable[0, _cnt]) { _modifierTable[0, _cnt] = -1; }
            else if (_colourTable[1, _cnt] == _colourTable[0, _cnt]) { _modifierTable[0, _cnt] = 0; }


            //fill step value
            if (_modifierTable[0, _cnt] == 1)
            {
                _modifierTable[1, _cnt] = _colourTable[1, _cnt] - _colourTable[0, _cnt];
            }
            else if (_modifierTable[0, _cnt] == -1)
            {
                _modifierTable[1, _cnt] = _colourTable[0, _cnt] - _colourTable[1, _cnt];
            }
            else if (_modifierTable[0, _cnt] == 0)
            {
                _modifierTable[1, _cnt] = 0;
            }
            _colourTable[2, _cnt] = (byte)(_colourTable[0, _cnt] + (((float)_modifierTable[1, _cnt] * ((float)colourIndex / (float)bandwidth)) * _modifierTable[0, _cnt]));

        }
    }
}
